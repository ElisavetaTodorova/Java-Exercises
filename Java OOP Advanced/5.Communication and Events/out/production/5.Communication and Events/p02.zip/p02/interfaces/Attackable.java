package p02.interfaces;

/**
 * Created by ELISAV on 12.9.2016 г..
 */
public interface Attackable  {

    void handleAttack();

}
