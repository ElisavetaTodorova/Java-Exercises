package P03_DependencyInversion.interfaces;

/**
 * Created by ELISAV on 12.9.2016 г..
 */
public interface Strategy {

    int Calculate(int firstOperand, int secondOperand);

}
