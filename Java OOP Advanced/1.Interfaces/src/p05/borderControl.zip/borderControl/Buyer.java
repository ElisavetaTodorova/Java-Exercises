package p05.borderControl;


public interface Buyer {

    void buyFood();
    int getTotalFoodCount();


}
