package p05.borderControl;


public class Robot extends Inhabitant {

    public Robot(String name, String id) {
        super(name, id);
    }
}
