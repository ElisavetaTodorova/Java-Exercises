package p05.borderControl;

/**
 * Created by ELISAV on 7.9.2016 г..
 */
public interface Birth {

    String getBirthDate();

    boolean hasSameYearOfBirth(String date);

}
