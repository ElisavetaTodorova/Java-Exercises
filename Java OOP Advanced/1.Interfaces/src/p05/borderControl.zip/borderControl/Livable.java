package p05.borderControl;

/**
 * Created by ELISAV on 7.9.2016 г..
 */
public interface Livable {

    boolean canInhabited(String id);

}
