package p03.ferrari.interfaces;



/**
 * Created by ELISAV on 7.9.2016 г..
 */
public interface Car {

    String breaks();

    String gasPedal();
    String getMODEL();


}
