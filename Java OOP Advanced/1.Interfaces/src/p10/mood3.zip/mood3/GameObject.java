package p10.mood3;

/**
 * Created by ELISAV on 8.9.2016 г..
 */
public interface GameObject {

    String getUserName();
    String getHashedPassword();
    int getLevel();



}
