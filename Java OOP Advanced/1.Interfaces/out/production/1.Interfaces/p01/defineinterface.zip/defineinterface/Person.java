package p01.defineinterface;

public interface Person {

    String getName();
    int getAge();


}
