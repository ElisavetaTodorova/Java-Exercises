package p04.telephony;

/**
 * Created by ELISAV on 7.9.2016 г..
 */
public interface Callable {
    String call();

}
