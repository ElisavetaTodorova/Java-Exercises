package p06Animals;

/**
 * Created by ELISAV on 5.9.2016 г..
 */
public interface Soundable {
    void produceSound();

}
