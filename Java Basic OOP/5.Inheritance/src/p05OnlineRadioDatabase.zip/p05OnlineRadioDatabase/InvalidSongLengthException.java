package p05OnlineRadioDatabase;

/**
 * Created by ELISAV on 5.9.2016 г..
 */
public class InvalidSongLengthException  extends InvalidSongException{

    public InvalidSongLengthException(String message) {
        super(message);
    }
}
