package p05OnlineRadioDatabase;

/**
 * Created by ELISAV on 5.9.2016 г..
 */
public class InvalidSongNameException extends InvalidSongException {

    public InvalidSongNameException(String message) {
        super(message);
    }
}
