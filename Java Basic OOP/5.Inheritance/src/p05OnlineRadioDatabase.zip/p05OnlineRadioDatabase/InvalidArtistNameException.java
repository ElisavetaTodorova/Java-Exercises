package p05OnlineRadioDatabase;

/**
 * Created by ELISAV on 5.9.2016 г..
 */
public class InvalidArtistNameException extends InvalidSongException {

    public InvalidArtistNameException(String message) {
        super(message);
    }
}
