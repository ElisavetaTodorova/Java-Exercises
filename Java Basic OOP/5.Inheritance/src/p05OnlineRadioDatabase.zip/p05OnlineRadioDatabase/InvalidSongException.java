package p05OnlineRadioDatabase;

/**
 * Created by ELISAV on 5.9.2016 г..
 */
public class InvalidSongException extends RuntimeException {

    public InvalidSongException(String message) {
        super(message);
    }
}
