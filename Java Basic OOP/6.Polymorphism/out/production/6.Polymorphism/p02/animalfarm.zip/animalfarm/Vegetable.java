package p02.animalfarm;


public class Vegetable extends Food {

    protected Vegetable(Integer quantity) {
        super(quantity);
    }
}
